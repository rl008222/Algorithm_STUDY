package com.ssafy.hw02;

public class BmiCalculator {
	public static void main(String[] args) {
		System.out.println("Bmi");
	}
}
